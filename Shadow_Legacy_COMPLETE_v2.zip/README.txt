# Shadow Legacy — édition iPhone

Version complète web mobile.

## Fichiers
- index.html
- style.css
- texture.css
- game.js

Le pack `texture.css` est déjà relié automatiquement à `index.html`.
Aucune ligne supplémentaire n'est à ajouter.

## Chapitres
La progression est dans l'ordre :
1. Ruines d'Asteria
2. Forêt des Murmures
3. Cœur du Néant

Le bouton JOUER lance uniquement le chapitre actuellement débloqué.
Le chapitre suivant est débloqué après la victoire sur le boss.

## Commandes
Sur iPhone : croix directionnelle, attaque et dash.
Clavier : flèches, Espace = attaque, Maj = dash, Échap = pause.

## GitHub Pages
Mets les quatre fichiers principaux à la racine du dépôt :
index.html, style.css, texture.css et game.js.

Puis GitHub :
Settings → Pages → Deploy from a branch → main → /(root) → Save.
