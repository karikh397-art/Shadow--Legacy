# Shadow Legacy — version iPhone

Jeu web mobile autonome en HTML/CSS/JavaScript.

## Fichiers
- `index.html` : page du jeu
- `style.css` : interface et visuels
- `game.js` : gameplay, histoire, ennemis, boss, boutique et sauvegarde

## Jouer
Ouvre `index.html` dans un navigateur. Le jeu fonctionne sans serveur et sans image externe.

## GitHub Pages
1. Crée un dépôt GitHub.
2. Ajoute les 3 fichiers à la racine du dépôt.
3. Va dans **Settings → Pages**.
4. Choisis **Deploy from a branch**, puis la branche principale et `/(root)`.
5. Enregistre et ouvre l'adresse GitHub Pages indiquée par GitHub.

GitHub Pages publie les fichiers HTML/CSS/JavaScript du dépôt comme un site web.
