(() => {
"use strict";
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const screens={menu:$("#menu"),story:$("#story"),shop:$("#shop"),settings:$("#settings"),game:$("#game"),gameover:$("#gameover"),victory:$("#victory")};
const saveKey="shadowLegacySaveV1";
let save=JSON.parse(localStorage.getItem(saveKey)||"null")||{coins:0,power:1,health:1,speed:1,chapter:1,music:true,vibe:true,comfort:false};
function persist(){localStorage.setItem(saveKey,JSON.stringify(save));updateShop()}
function show(name){Object.values(screens).forEach(x=>x.classList.remove("active"));screens[name].classList.add("active");if(name==="shop")updateShop();if(name==="menu"){$("#menuCoins").textContent=save.coins+" ✦"}}
$$("[data-back]").forEach(b=>b.onclick=()=>show("menu"));
$("#playBtn").onclick=()=>startGame(save.chapter);
$("#shopBtn").onclick=()=>show("shop"); $("#settingsBtn").onclick=()=>show("settings"); $("#storyBtn").onclick=()=>show("story");
$("#musicToggle").checked=save.music;$("#vibeToggle").checked=save.vibe;$("#comfortToggle").checked=save.comfort;
$("#musicToggle").onchange=e=>{save.music=e.target.checked;persist()};$("#vibeToggle").onchange=e=>{save.vibe=e.target.checked;persist()};$("#comfortToggle").onchange=e=>{save.comfort=e.target.checked;document.body.classList.toggle("comfort",save.comfort);persist()};
$("#resetBtn").onclick=()=>{if(confirm("Effacer toute la progression ?")){localStorage.removeItem(saveKey);location.reload()}};
function updateShop(){
 $("#shopCoins").textContent=save.coins;$("#menuCoins").textContent=save.coins+" ✦";
 ["power","health","speed"].forEach(k=>{$("#"+k+"Cost").textContent=(30+Math.max(0,save[k]-1)*25)+" ✦"});
}
$$(".upgrade").forEach(b=>b.onclick=()=>{let k=b.dataset.upgrade,cost=30+Math.max(0,save[k]-1)*25;if(save.coins>=cost){save.coins-=cost;save[k]++;persist();toast("Amélioration achetée !")}else toast("Pas assez de fragments.")});
function toast(t){let m=$("#message");m.textContent=t;m.classList.add("show");setTimeout(()=>m.classList.remove("show"),1200)}

const canvas=$("#gameCanvas"),ctx=canvas.getContext("2d");
let W,H,dpr,raf,last=0,running=false,paused=false,chapter=1,player,enemies,particles,keys={},boss=null,world;
function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();
function startGame(ch=1){
 chapter=ch; show("game"); paused=false; $("#pause").classList.add("hidden");
 player={x:W/2,y:H*.58,r:20,hp:100+save.health*18,max:100+save.health*18,speed:190+save.speed*12,energy:0,inv:0,attack:0};
 enemies=[];particles=[];boss=null;world={time:0,spawn:0,goal:chapter===3?1:18+chapter*8,defeated:0};
 $("#chapter").textContent=chapter===1?"CHAPITRE I — RUINES D'ASTERIA":chapter===2?"CHAPITRE II — FORÊT DES MURMURES":"CHAPITRE III — CŒUR DU NÉANT";
 $("#bossName").textContent="";running=true;last=performance.now();raf=requestAnimationFrame(loop);toast(chapter===1?"Traverse les ruines.":chapter===2?"La forêt t'observe.":"Le Cœur du Néant t'attend.");
}
function spawnEnemy(){
 let side=Math.floor(Math.random()*4),x=side<2?Math.random()*W:(side===2?-30:W+30),y=side<2?(side===0?-30:H+30):Math.random()*H;
 let elite=Math.random()<.16;
 enemies.push({x,y,r:elite?20:15,hp:elite?48:28,max:elite?48:28,speed:elite?48:62,damage:elite?14:9,elite,hit:0});
}
function spawnBoss(){
 boss={x:W/2,y:100,r:42,hp:360+chapter*100,max:360+chapter*100,phase:0,hit:0};
 $("#bossName").textContent=chapter===1?"LE GARDIEN DE BRUME":chapter===2?"LA REINE DES MURMURES":"LE CŒUR DU NÉANT";
 toast("BOSS : "+$("#bossName").textContent);
}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function move(dt){
 let dx=(keys.right?1:0)-(keys.left?1:0),dy=(keys.down?1:0)-(keys.up?1:0);
 if(dx||dy){let l=Math.hypot(dx,dy);player.x+=dx/l*player.speed*dt;player.y+=dy/l*player.speed*dt}
 player.x=Math.max(25,Math.min(W-25,player.x));player.y=Math.max(70,Math.min(H-25,player.y));player.inv=Math.max(0,player.inv-dt);player.attack=Math.max(0,player.attack-dt);
}
function hitTarget(){
 if(player.attack>0)return;
 player.attack=.28;
 burst(player.x,player.y,12,"#61e7ff");
 for(let e of enemies){if(dist(player,e)<92){e.hp-=28+save.power*10;e.hit=.12}}
 if(boss&&dist(player,boss)<115){boss.hp-=22+save.power*8;boss.hit=.12}
}
function dash(){
 if(player.energy<100)return toast("Énergie insuffisante");
 player.energy=0;player.inv=.45;burst(player.x,player.y,22,"#9a8cff");
 let dx=(keys.right?1:0)-(keys.left?1:0),dy=(keys.down?1:0)-(keys.up?1:0);if(!dx&&!dy)dy=-1;let l=Math.hypot(dx,dy);player.x+=dx/l*120;player.y+=dy/l*120;
}
function enemyAI(e,dt){
 let dx=player.x-e.x,dy=player.y-e.y,l=Math.hypot(dx,dy)||1;e.x+=dx/l*e.speed*dt;e.y+=dy/l*e.speed*dt;e.hit=Math.max(0,e.hit-dt);
 if(l<e.r+player.r+4&&player.inv<=0){player.hp-=e.damage;player.inv=.45;burst(player.x,player.y,8,"#ff6680")}
}
function bossAI(b,dt){
 b.hit=Math.max(0,b.hit-dt);let dx=player.x-b.x,dy=player.y-b.y,l=Math.hypot(dx,dy)||1;
 b.x+=dx/l*(38+chapter*7)*dt;b.y+=dy/l*(38+chapter*7)*dt;
 if(b.phase<=0&&Math.random()<dt*.8){b.phase=1;setTimeout(()=>{if(boss)b.phase=0},900)}
 if(l<70&&player.inv<=0){player.hp-=20;player.inv=.5}
}
function update(dt){
 world.time+=dt;move(dt);
 if(!boss){world.spawn-=dt;if(world.spawn<=0&&enemies.length<8){spawnEnemy();world.spawn=Math.max(.25,.8-world.time*.005)}}
 enemies.forEach(e=>enemyAI(e,dt));
 enemies=enemies.filter(e=>{if(e.hp<=0){world.defeated++;save.coins+=e.elite?7:3;burst(e.x,e.y,16,e.elite?"#ffd76a":"#61e7ff");return false}return true});
 if(!boss&&world.defeated>=world.goal)spawnBoss();
 if(boss){bossAI(boss,dt);if(boss.hp<=0){save.coins+=80;persist();running=false;$("#victoryTitle").textContent="Victoire sur "+$("#bossName").textContent;$("#victoryText").textContent="Tu as gagné 80 fragments. Le prochain chapitre est désormais accessible.";$("#nextBtn").style.display=chapter<3?"block":"none";save.chapter=Math.min(3,chapter+1);persist();show("victory");return}}
 player.energy=Math.min(100,player.energy+dt*22);
 $("#hpText").textContent=Math.max(0,Math.ceil(player.hp));$("#hpBar").style.width=Math.max(0,player.hp/player.max*100)+"%";$("#coins").textContent=save.coins;
 if(player.hp<=0){running=false;$("#gameoverText").textContent="Fragments gagnés : "+save.coins+" ✦";show("gameover")}
 particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;p.vx*=.97;p.vy*=.97});particles=particles.filter(p=>p.life>0);
}
function burst(x,y,n,c){for(let i=0;i<n;i++){let a=Math.random()*Math.PI*2,s=40+Math.random()*150;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.4+Math.random()*.5,c})}}
function draw(){
 ctx.clearRect(0,0,W,H);
 let g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,"#0c2d58");g.addColorStop(1,"#061329");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 ctx.globalAlpha=.18;ctx.strokeStyle="#65e7ff";for(let x=0;x<W;x+=60){ctx.beginPath();ctx.moveTo(x,65);ctx.lineTo(x,H);ctx.stroke()}for(let y=90;y<H;y+=60){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}ctx.globalAlpha=1;
 // ruins / trees
 for(let i=0;i<9;i++){let x=(i*137+50)%W,y=100+(i*83)%Math.max(120,H-160);ctx.fillStyle=i%2?"#12345a":"#173d5e";ctx.fillRect(x,y,28,70);ctx.beginPath();ctx.arc(x+14,y,25,0,7);ctx.fill()}
 enemies.forEach(e=>drawEnemy(e));if(boss)drawBoss(boss);drawPlayer();
 particles.forEach(p=>{ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=p.c;ctx.beginPath();ctx.arc(p.x,p.y,3+p.life*4,0,7);ctx.fill()});ctx.globalAlpha=1;
}
function drawPlayer(){ctx.save();ctx.translate(player.x,player.y);if(player.inv%0.12<0.06)ctx.globalAlpha=.55;ctx.shadowBlur=20;ctx.shadowColor="#61e7ff";ctx.fillStyle="#61e7ff";ctx.beginPath();ctx.arc(0,0,player.r,0,7);ctx.fill();ctx.fillStyle="#071a38";ctx.beginPath();ctx.arc(0,0,10,0,7);ctx.fill();ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(7,-7,4,0,7);ctx.fill();ctx.restore()}
function drawEnemy(e){ctx.save();ctx.translate(e.x,e.y);ctx.shadowBlur=15;ctx.shadowColor=e.elite?"#ffd76a":"#c982ff";ctx.fillStyle=e.elite?"#ffd76a":"#a979ff";ctx.beginPath();for(let i=0;i<8;i++){let a=i*Math.PI/4,r=i%2?e.r*.65:e.r;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.fill();ctx.restore()}
function drawBoss(b){ctx.save();ctx.translate(b.x,b.y);ctx.shadowBlur=35;ctx.shadowColor="#ff6680";ctx.fillStyle="#d75a91";ctx.beginPath();ctx.arc(0,0,b.r,0,7);ctx.fill();ctx.fillStyle="#ffd76a";ctx.beginPath();ctx.arc(-12,-5,6,0,7);ctx.arc(12,-5,6,0,7);ctx.fill();ctx.fillStyle="#07122b";ctx.fillRect(-32,-60,64,7);ctx.fillStyle="#ff6680";ctx.fillRect(-32,-60,64*(b.hp/b.max),7);ctx.restore()}
function loop(t){if(!running)return;let dt=Math.min(.033,(t-last)/1000);last=t;if(!paused){update(dt);draw()}raf=requestAnimationFrame(loop)}
function bindHold(id,k){let b=$("#"+id);["pointerdown"].forEach(ev=>b.addEventListener(ev,e=>{e.preventDefault();keys[k]=true}));["pointerup","pointercancel","pointerleave"].forEach(ev=>b.addEventListener(ev,e=>{e.preventDefault();keys[k]=false}))}
bindHold("left","left");bindHold("right","right");bindHold("up","up");bindHold("down","down");
$("#attack").onpointerdown=e=>{e.preventDefault();hitTarget()};$("#dash").onpointerdown=e=>{e.preventDefault();dash()};
addEventListener("keydown",e=>{if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"," "].includes(e.key))e.preventDefault();if(e.key==="ArrowLeft")keys.left=true;if(e.key==="ArrowRight")keys.right=true;if(e.key==="ArrowUp")keys.up=true;if(e.key==="ArrowDown")keys.down=true;if(e.key===" ")hitTarget();if(e.key==="Shift")dash();if(e.key==="Escape"&&screens.game.classList.contains("active"))togglePause()});
addEventListener("keyup",e=>{if(e.key==="ArrowLeft")keys.left=false;if(e.key==="ArrowRight")keys.right=false;if(e.key==="ArrowUp")keys.up=false;if(e.key==="ArrowDown")keys.down=false});
function togglePause(){if(!running)return;paused=!paused;$("#pause").classList.toggle("hidden",!paused)}
$("#resumeBtn").onclick=togglePause;$("#quitBtn").onclick=()=>{running=false;show("menu")};
$("#retryBtn").onclick=()=>startGame(chapter);$("#goMenuBtn").onclick=()=>show("menu");$("#victoryMenu").onclick=()=>show("menu");$("#nextBtn").onclick=()=>startGame(Math.min(3,chapter+1));
document.body.classList.toggle("comfort",save.comfort);updateShop();
})();
